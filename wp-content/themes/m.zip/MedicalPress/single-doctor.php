<?php
/*
 *  Single Doctor
 */

get_template_part( INSPIRY_PARTIALS . '/doctor/single/single-doctor' );