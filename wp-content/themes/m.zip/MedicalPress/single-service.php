<?php
/*
 *  Single Service
 */

get_template_part( INSPIRY_PARTIALS . '/services/single/single-service' );