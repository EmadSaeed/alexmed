<?php
/**
 * The main template file
 */

get_template_part( INSPIRY_PARTIALS . '/blog/blog-index' );