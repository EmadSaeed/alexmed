<?php
/*
*  Template Name: Home Template
*/
get_header();

get_template_part( INSPIRY_PARTIALS . '/home/home' );

get_footer();