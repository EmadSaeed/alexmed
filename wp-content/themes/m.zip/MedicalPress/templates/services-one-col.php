<?php
/*
 *  Template Name: Services 1 Column Template
 */

get_template_part( INSPIRY_PARTIALS . '/services/services-common' );