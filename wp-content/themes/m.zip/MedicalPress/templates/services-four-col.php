<?php
/*
 *  Template Name: Services 4 Columns Template
 */

get_template_part( INSPIRY_PARTIALS . '/services/services-common' );