<?php
/*
*   Template Name: Full Width Template
*/

get_template_part( INSPIRY_PARTIALS . '/page/page-fullwidth' );