<?php
/*
 *  Template Name: Services 3 Columns Template
 */

get_template_part( INSPIRY_PARTIALS . '/services/services-common' );