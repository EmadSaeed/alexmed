<?php
/*
*   Template Name: WooCommerce Template
*/

get_template_part( INSPIRY_PARTIALS . '/page/woocommerce' );