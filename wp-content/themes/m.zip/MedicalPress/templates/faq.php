<?php
/*
 *  Template Name: FAQs Template
 */

get_template_part( INSPIRY_PARTIALS . '/page/page-faq' );