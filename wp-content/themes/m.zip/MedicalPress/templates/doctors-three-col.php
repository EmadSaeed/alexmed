<?php
/*
 *  Template Name: Doctors 3 Columns Template
 */

get_template_part( INSPIRY_PARTIALS . '/doctor/doctors-common' );