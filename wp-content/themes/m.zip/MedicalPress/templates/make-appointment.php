<?php
/*
 *  Template Name: Appointment Template
 */

get_template_part( INSPIRY_PARTIALS . '/page/page-make-appointment' );