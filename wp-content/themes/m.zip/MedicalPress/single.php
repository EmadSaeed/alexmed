<?php
/*
 *  Single
 */

get_template_part( INSPIRY_PARTIALS . '/blog/single' );