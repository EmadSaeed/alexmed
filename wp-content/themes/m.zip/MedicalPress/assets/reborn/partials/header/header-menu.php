<nav id="main-navigation" class="main-navigation">
	<?php
	wp_nav_menu( array(
		'theme_location' => 'main-menu',
		'container'      => false,
		'menu_class'     => 'main-menu clearfix'
	) );
	?>
</nav>