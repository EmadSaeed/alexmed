<div class="gallery gallery-slider flexslider">
    <?php  inspiry_list_gallery_images() ?>
</div>