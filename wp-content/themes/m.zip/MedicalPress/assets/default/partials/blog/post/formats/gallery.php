<div class="gallery gallery-slider clearfix">
    <?php  inspiry_list_gallery_images() ?>
</div>